clear all;

% DATA INPUT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% ***UNCOMMENT TO RUN IN INTERACTIVE MODE
%prompt='Enter number of parameters to optimize: '
%num_params_to_opt=input(prompt);

% NON-INTERACTIVE HARD CODING
num_params_to_opt=2;

% ***UNCOMMENT TO RUN IN INTERACTIVE MODE
%prompt='Enter number of PES difference potential data files: '
%num_PES_files=input(prompt);

% NON-INTERACTIVE HARD CODING
num_PES_files=1;

% Stores geometries for each parameter in 2D array (param#,geometries)
% Note geometries are imported as row vectors from csv files below
param_geoms_combined=[];

% Stores multiplicites to be implemented for each parameter
param_mult_terms=[];

% Stores the number of columns utilized by each parameter
param_cols=[];

% Stores 0/1 to indicate fixed/variabel phase dihedral
param_phase_indicator=[];

for a=1:num_params_to_opt
    
    a_chr=int2str(a);
    
    % Temp array to concatenate parameter geometries from input files
    concat_array=[];
    
    % Temp array to store desired multiplicities for parameter #i
    temp_mult_array=[];
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % UNCOMMENT TO RUN IN INTERACTIVE MODE
    %prompt=strcat('Enter desired multiplicites for parameter #',a_chr,' as an array 1-6 separated by spaces only (e.g. [# # #]): ');
    %temp_mult_array=input(prompt)
    
    % NON-INTERACTIVE HARD CODING
    temp_mult_array=[1 2 3 4 5 6];
    
    param_mult_terms=[param_mult_terms temp_mult_array];
    
    param_cols(a)=size(temp_mult_array,2);
    
    % UNCOMMENT TO RUN IN INTERACTIVE MODE
    %prompt=strcat('For parameter #',a_chr,', enter 0 for fixed phase or 1 for variable phase: ');    
    %param_phase_indicator(a)=input(prompt)
    
    % NON-INTERACTIVE HARD CODING
    param_phase_indicator(a)=1;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % FILES MUST BE NAMED: 'Param#-Geoms-PES#.txt'
    % Must include a file for each parameter's geometries from each PES
    % e.g. 6 parameters and 5 PESs requires the files:
    %      Param1-Geoms-PES1.txt ... Param1-Geoms-PES5.txt
    %               .                         . 
    %               .                         .
    %               .                         .
    %      Param6-Geoms-PES1.txt ... Param6-Geoms-PES5.txt
    for b=1:num_PES_files
        
        b_chr=int2str(b);
        
        input_file_name=strcat('Param',a_chr,'-Geoms-PES',b_chr,'.txt');
        
        array_from_file=importdata(input_file_name,',',0);   
                
        concat_array=[concat_array array_from_file]; 
            
    end    
    
    param_geoms_combined(a,:)=concat_array;
end

diff_pot_combined=[];

for b=1:num_PES_files
          
    b_chr=int2str(b);
    
    concat_array=[];
    
    input_file_name=strcat('Diff-Potential',b_chr,'.txt');
    
    array_from_file=importdata(input_file_name,',',0);
    
    diff_pot_combined=[diff_pot_combined array_from_file];
end

% END DATA INPUT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% POPULATE MATRICES
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[m,n]=size(param_geoms_combined);
rows=n;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cols=0;

for i=1:num_params_to_opt
    if param_phase_indicator(i)==1
        param_cols(i)=param_cols(i)*2;
    end
    
    cols = cols+param_cols(i);
end

%cols    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cT=0;
for i=1:rows
 cT=cT+diff_pot_combined(i); 
end

cT=cT/rows;

for i=1:rows
 diff_pot_combined(i)=diff_pot_combined(i)-cT;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

j_start=0;

term_counter=1;

for a=1:num_params_to_opt
     
    j_end=0;
    
    for b=1:a
        j_end=j_end+param_cols(b);
    end    
    
    %j_start
    %j_end
    
    if param_phase_indicator(a)==0
        for j=j_start+1:j_end
            %j
            %param_mult_terms(term_counter)
            cR=0;
            for i=1:rows
                Ak(i,j)=1+cos(param_mult_terms(term_counter)*pi/180.0.*param_geoms_combined(a,i));
                cR=cR+Ak(i,j);
            end 
    
            %Ak
            
            cR=cR/rows;
    
            for i=1:rows
                Ak(i,j)=Ak(i,j)-cR;
            end        
            term_counter=term_counter+1            
        end
        
    else
        for j=j_start+1:2:j_end
            %j
            %param_mult_terms(term_counter)
            cRodd=0;
            cReven=0;
            for i=1:rows            
                Ak(i,j)=cos(param_mult_terms(term_counter)*pi/180.0.*param_geoms_combined(a,i));
                cRodd=cRodd+Ak(i,j);
                Ak(i,j+1)=sin(param_mult_terms(term_counter)*pi/180.0.*param_geoms_combined(a,i));	
                cReven=cReven+Ak(i,j+1);
            end  
    
            %Ak
            
            cRodd=cRodd/rows;
            cReven=cReven/rows;
    
            for i=1:rows
                Ak(i,j)=Ak(i,j)-cRodd;
                Ak(i,j+1)=Ak(i,j+1)-cReven;
            end  
    
            term_counter=term_counter+1;
        end        
    end 
    
    j_start=j_end;
    
end

% END POPULATE MATRICES
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% CALCULATE SVD (NOT TRUNCATED)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

y=diff_pot_combined;

[U,S,V]=svd(Ak);

ST=S;

[ms,ns]=size(ST);

rsvd=length(find(diag(S)));

Uhat=U(:,1:rsvd);

Shat=S(1:rsvd,1:rsvd);

Vhat=V(:,1:rsvd);

zsvd=Shat\Uhat'*y';

csvd=V*zsvd;

B1_0=Ak*csvd;

% END CALCULATE SVD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for j=1:35000
    
    lambda_step=0.0005;
        
    lambda=0.0+lambda_step*j;
    
    rsvdREG=length(find(diag(S)));

    UhatREG=U(:,1:rsvdREG);

    ShatREG=S(1:rsvd,1:rsvdREG);
        
    for i=1:cols
        ShatREG(i,i)=(ShatREG(i,i)*ShatREG(i,i)+lambda*lambda)/ShatREG(i,i);
    end

    VhatREG=V(:,1:rsvdREG);

    zsvdREG=ShatREG\UhatREG'*y';

    csvdREG=VhatREG*zsvdREG;
    
    soln_norm_matrixREG(j)=norm(csvdREG);
    
    BprimeREG=Ak*csvdREG;
    
    res_norm_matrixREG(j)=norm(B1_0-BprimeREG);     
    
    reg_iterations=j;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i=cols:-1:1
    S_trunc=S;
    
    for j=cols:-1:i
        S_trunc(j,j)=0;        
    end
    
    S_trunc;
    
    rsvdT1=length(find(diag(S_trunc)));

    UhatT1=U(:,1:rsvdT1);

    ShatT1=S_trunc(1:rsvdT1,1:rsvdT1);

    VhatT1=V(:,1:rsvdT1);

    zsvdT1=ShatT1\UhatT1'*y';

    csvdT1=VhatT1*zsvdT1;
    
    soln_norm_matrix(cols+1-i)=norm(csvdT1);
    
    BprimeSVDT1=Ak*csvdT1;
    
    res_norm_matrix(cols+1-i)=norm(B1_0-BprimeSVDT1);    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i=1:cols-1
    gaps(i)=S(i+1,i+1)/S(i,i);
end

for i=1:cols
    crit(i)=S(1,1)/S(i,i);
end

beta_decay=abs(Uhat'*y')';

for i=1:cols
    sigma_decay(i)=S(i,i);
    DPC(i)=beta_decay(i)/S(i,i);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(1)
plot(log(res_norm_matrixREG),log(soln_norm_matrixREG))

hold on

plot(log(res_norm_matrix),log(soln_norm_matrix),'rd')

grid on

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(2)

plot(log(DPC),'-vg')
hold on
plot(log(beta_decay),'-ob')
hold on
plot(log(sigma_decay),'-sr')

grid on

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

prompt='Enter 0 to truncate by singular value tolerace OR 1 to truncate by index:';

indicate_tol_or_ind=input(prompt);

if indicate_tol_or_ind==0

    prompt='Enter singular value truncation tolerance: ';
    
    trunc_k=input(prompt);
        
    for i=1:ms
    	for j=1:ns
    	     if ST(i,j)<trunc_k 
    	        ST(i,j)=0;
             end
        end
    end
    
else
    prompt='Enter index at which to truncate: ';
    
    trunc_k=input(prompt);
    
    for i=1:ms
    	for j=1:ns
    	     if j>trunc_k 
    	        ST(i,j)=0;
             end
        end
    end
    
end

rsvdT=length(find(diag(ST)));

UhatT=U(:,1:rsvdT);

ShatT=ST(1:rsvdT,1:rsvdT);

VhatT=V(:,1:rsvdT);

zsvdT=ShatT\UhatT'*y';

csvdT=VhatT*zsvdT;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

prompt='Enter 0 to input regularization parameter manually OR 1 to use sqrt(sigma_k * sigma_k+1):';

indicate_manual_or_calc=input(prompt);

if indicate_manual_or_calc==0
    prompt='Enter value for regularization parameter:';
    lambda1=input(prompt);
else
    lambda1=sqrt(Shat(rsvdT,rsvdT)*Shat(rsvdT+1,rsvdT+1));
end
    
rsvdREG1=length(find(diag(S)));

UhatREG1=U(:,1:rsvdREG1);

ShatREG1=S(1:rsvd,1:rsvdREG1);
        
for i=1:cols
    ShatREG1(i,i)=(ShatREG1(i,i)*ShatREG1(i,i)+lambda1*lambda1)/ShatREG1(i,i);
end

VhatREG1=V(:,1:rsvdREG1);

zsvdREG1=ShatREG1\UhatREG1'*y';

csvdREG1=VhatREG1*zsvdREG1;
    
soln_norm_REG1=norm(csvdREG1);
    
BprimeREG1=Ak*csvdREG1;
   
res_norm_REG1=norm(B1_0-BprimeREG1);
        
BprimeREG1=Ak*csvdREG1;
B=y';

RMSEREG1=sqrt(mean((BprimeREG1-B).^2));

rsvdT_chr=int2str(rsvdT);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fileID=fopen('0_25_TSVD_Parameters_Formatted.txt','w');
fprintf(fileID,'%s\n','**Truncation k:');
fprintf(fileID,'%i\n',rsvdT);
fprintf(fileID,'\n');
fclose(fileID);

fileIDR=fopen('0_25_REG_Parameters_Formatted.txt','w');
fprintf(fileIDR,'%s\n','**Lambda');
fprintf(fileIDR,'%f\n',lambda1);
fprintf(fileIDR,'\n');
fclose(fileIDR);

j_start=0;

index_counter=1;

for a=1:num_params_to_opt
     
    j_end=0;
    
    for b=1:a
        j_end=j_end+param_cols(b);
    end    
    
    %j_start
    %j_end
    
    if param_phase_indicator(a)==0
        fileID=fopen('0_25_TSVD_Parameters_Formatted.txt','a');
        fileIDR=fopen('0_25_REG_Parameters_Formatted.txt','a');
        param_term_counter=1;
        for i=j_start+1:j_end
            force_consts_TSVD(index_counter)=csvdT(i);
            forceconstREG1(index_counter)=csvdREG1(i);
    
            if force_consts_TSVD(index_counter)<0.0
                force_consts_TSVD(index_counter)=-1*force_consts_TSVD(index_counter);
                delta_TSVD(index_counter)=180.0;
            else
                delta_TSVD(index_counter)=0.0;
            end
            
            if forceconstREG1(index_counter)<0.0
                forceconstREG1(index_counter)=-1*forceconstREG1(index_counter);
                deltaREG1(index_counter)=180.0;
            else
                deltaREG1(index_counter)=0.0;
            end
    
            fprintf(fileID,'%f ',force_consts_TSVD(index_counter));
            fprintf(fileID,'%i ',param_mult_terms(index_counter));
            fprintf(fileID,'%f\n',delta_TSVD(index_counter));
            
            fprintf(fileIDR,'%f ',forceconstREG1(index_counter));
            fprintf(fileIDR,'%i ',param_mult_terms(index_counter));
            fprintf(fileIDR,'%f\n',deltaREG1(index_counter));
            
            param_term_counter=param_term_counter+1;
    
            index_counter=index_counter+1;
        end
        fprintf(fileID,'\n');
        fclose(fileID);
        
        fprintf(fileIDR,'\n');
        fclose(fileIDR);
    
    else
        fileID=fopen('0_25_TSVD_Parameters_Formatted.txt','a');
        fileIDR=fopen('0_25_REG_Parameters_Formatted.txt','a');
        param_term_counter=1;
        for i=j_start+1:2:j_end
            force_consts_TSVD(index_counter)=sqrt(csvdT(i)*csvdT(i)+csvdT(i+1)*csvdT(i+1));
            delta_TSVD(index_counter)=(180.0/pi).*atan2(csvdT(i+1),csvdT(i));
    
            forceconstREG1(index_counter)=sqrt(csvdREG1(i)*csvdREG1(i)+csvdREG1(i+1)*csvdREG1(i+1));
            deltaREG1(index_counter)=(180.0/pi).*atan2(csvdREG1(i+1),csvdREG1(i));
            
            fprintf(fileID,'%f ',force_consts_TSVD(index_counter));
            fprintf(fileID,'%i ',param_mult_terms(index_counter));
            fprintf(fileID,'%f\n',delta_TSVD(index_counter));
            
            fprintf(fileIDR,'%f ',forceconstREG1(index_counter));
            fprintf(fileIDR,'%i ',param_mult_terms(index_counter));
            fprintf(fileIDR,'%f\n',deltaREG1(index_counter));
            
            param_term_counter=param_term_counter+1;
    
            index_counter=index_counter+1;
        end   
        fprintf(fileID,'\n');
        fclose(fileID);
        
        fprintf(fileIDR,'\n');
        fclose(fileIDR);
    end
    
    j_start=j_end;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fileID=fopen('0_20_decay.txt','w');
fprintf(fileID,'%s\n','**truncation k:');
fprintf(fileID,'%f\n',trunc_k);
fprintf(fileID,'%s\n','**sigma decay:');
fprintf(fileID,'%f\n',sigma_decay);
fprintf(fileID,'%s\n','**DPC:');
fprintf(fileID,'%f\n',DPC);
fprintf(fileID,'%s\n','**beta_decay:');
fprintf(fileID,'%f\n',beta_decay);
fclose(fileID);

fileID=fopen('0_21_reg_norms.txt','w');
fprintf(fileID,'%s\n','**lambda step:');
fprintf(fileID,'%f\n',lambda_step);
fprintf(fileID,'%s\n','**reg iterations:');
fprintf(fileID,'%f\n',reg_iterations);
fprintf(fileID,'%s\n','**final lambda:');
fprintf(fileID,'%f\n',lambda);
fprintf(fileID,'%s\n','**res norm:');
fprintf(fileID,'%f\n',res_norm_matrixREG);
fprintf(fileID,'%s\n','**soln norm:');
fprintf(fileID,'%f\n',soln_norm_matrixREG);
fclose(fileID);

fileID=fopen('0_22_trunc_norms.txt','w');
fprintf(fileID,'%s\n','**res norm:');
fprintf(fileID,'%f\n',res_norm_matrix);
fprintf(fileID,'%s\n','**soln norm:');
fprintf(fileID,'%f\n',soln_norm_matrix);
fclose(fileID);

fileID=fopen('0_24_gaps_crit.txt','w');
fprintf(fileID,'%s\n','**gaps:');
fprintf(fileID,'%f\n',gaps);
fprintf(fileID,'%s\n','**critical cond:');
fprintf(fileID,'%f\n',crit);
fclose(fileID);
