import os
import time

os.system('matlab -nodisplay -nodesktop -r "run z_new_mp2_new_mm_LS_UF1_loopFIX2.m"')

