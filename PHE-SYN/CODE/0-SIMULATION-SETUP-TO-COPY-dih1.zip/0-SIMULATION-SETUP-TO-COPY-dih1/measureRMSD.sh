psfPrefix=./dna_Na_WI
pdbPrefix=./dna_Na_WI
selText=nucleic
timestep=2 

#base=output/sim
#nTotal=`ls -l ${base}.*.*_RMSDAlignWrap_dna.dcd | wc -l`

outPut=sim_RMSD.dat
rm -f $outPut


#for k in 0.5 0.1 0.01 0 dcdPrefix=equil_k${k}
#do

    dcdPrefix=aqua-equil2
    xstPrefix=aqua-equil2

    vmd -dispdev text -e measureRMSD.tcl -args $psfPrefix $pdbPrefix $dcdPrefix $xstPrefix $selText $timestep $outPut

#done



