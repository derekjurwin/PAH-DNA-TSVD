import numpy as np
import os
import time
import math

import matplotlib.pyplot as plt

# READ QM ANGLES FROM QM LOG FILES INTO A LIST
# THESE ARE WRITTEN TO FILE AS THE scan_point#_coord.txt FILES ARE WRITTEN
# HENCE QM ANGLES CORREDPOND TO THOSE IN scan_point#_coord.txt
angles_ordered_by_scan_point_list=[]
in_from_file=open('0_5_angle_rosetta_stone.txt','r')
angle_rosetta_stone_list=in_from_file.readlines()
in_from_file.close()
for i in angle_rosetta_stone_list:
    c=i.split(',')
    angles_ordered_by_scan_point_list.append(float(c[1]))

# READ MM ENERGIES FROM minima.dat
# THESE ARE READ FROM THE NAMD LOG FILES THE CORRESPOND TO scan_point#_coord.txt
# HENCE THE ENERGIES CORRESPOND TO THE QM ANGLES ABOVE IN THE SAME ORDER
MM_energies_by_scan_point=[]
in_from_file=open('minima.dat','r')
minima_string_list=in_from_file.readlines()
in_from_file.close()
for i in minima_string_list:
    c=i.split()
    MM_energies_by_scan_point.append(float(c[1]))

MM_relative_energies_by_scan_point=[]
min_MM_energy=min(MM_energies_by_scan_point)
for i in MM_energies_by_scan_point:
    MM_relative_energies_by_scan_point.append(i-min_MM_energy)
   
# PUT QM ANGLES AND MM ENERGIES IN A DICTIONARY SO THEY ARE MARRIED
dict_MM_relative_energies_QM_angle_keyed={}
index_counter=0
for i in angles_ordered_by_scan_point_list:
    dict_MM_relative_energies_QM_angle_keyed[i]=MM_relative_energies_by_scan_point[index_counter]
    index_counter+=1
   
# SORT THE DICTIONARY AND CREATE NEW LISTS WHERE QM ANGLES AND MM ENERGIES ARE SORTED BY QM ANGLE
# IMPARATIVE FOR DIFFERENCE POTENTIAL AND PLOTTING
sorted_QM_angles_list=[]
sorted_MM_relative_energies_list=[]
for key in sorted(dict_MM_relative_energies_QM_angle_keyed):
    sorted_QM_angles_list.append(key)
    sorted_MM_relative_energies_list.append(dict_MM_relative_energies_QM_angle_keyed[key])

##########################################################################################################################
# TOSS DATA HERE
##########################################################################################################################
del sorted_QM_angles_list[18:19]
del sorted_MM_relative_energies_list[18:19]
    
in_from_file=open('0_3_QM_plot_data.txt','r')
QM_data_string_list=in_from_file.readlines()
QM_relative_energies_by_angle=[]
for i in QM_data_string_list:
    c=i.split(',')
    QM_relative_energies_by_angle.append(float(c[1]))
in_from_file.close()

##########################################################################################################################
# TOSS DATA HERE
##########################################################################################################################
del QM_relative_energies_by_angle[18:19]

difference_potential_list=[]
difference_potential_squared_list=[]
for i in range(len(sorted_MM_relative_energies_list)):
    difference_potential_list.append(QM_relative_energies_by_angle[i]-sorted_MM_relative_energies_list[i])
    difference_potential_squared_list.append(difference_potential_list[i]*difference_potential_list[i])

difference_potential_squared_avg=sum(difference_potential_squared_list)/len(difference_potential_squared_list)

RMSE=math.sqrt(difference_potential_squared_avg)

abs_error_list=[]
for i in difference_potential_list:
    abs_error_list.append(abs(i))
    
out_to_file=open('0_13_error_data_tossed.txt','w')
out_to_file.write('Max absolute error = '+str(max(abs_error_list))+'\n')
out_to_file.write('RMSE = '+str(RMSE)+'\n')
for i in range(len(sorted_QM_angles_list)):
    out_to_file.write(str(sorted_QM_angles_list[i])+' '+str(difference_potential_list[i])+'\n')
out_to_file.close()



