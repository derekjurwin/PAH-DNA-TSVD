import matplotlib.pyplot as plt

in_from_file=open('0_0_simulation_data.txt','r')

simulation_data=in_from_file.readlines()

in_from_file.close()

simulation_data[0]=simulation_data[0][:-1]
simulation_data[1]=simulation_data[1][:-1]
simulation_data[2]=simulation_data[2][:-1]
simulation_data[3]=simulation_data[3][:-1]

neg_scan_filename=simulation_data[0]
pos_scan_filename=simulation_data[1]

#in_from_file=open('PHE.scan1.neg.150deg-start.log.ffTK','r')
in_from_file=open(neg_scan_filename,'r')

plot_data_string_list1=in_from_file.readlines()

in_from_file.close()

angle_list1=[]
energy_list1=[]

for x in plot_data_string_list1:
    if 'dihedral' in x:
        y=x.split('=')
        angle_list1.append(float(y[1]))
    if 'EUMP2' in x:
        y=x.split('=')
        energy_string=''
        for i in y[2]:
            if i=='D':
                energy_string=energy_string+'E'
            else:
                energy_string=energy_string+i
        energy_list1.append(float(energy_string)*627.51)

print(angle_list1)
print(energy_list1)

min_energy1=min(energy_list1)

relative_energy_list1=[]

for i in energy_list1:
    relative_energy_list1.append(i-min_energy1)

print(relative_energy_list1)

out_to_file=open('file1-plot-data.txt','w')
for i in range(len(angle_list1)):
    out_to_file.write(str(angle_list1[i]))
    out_to_file.write(',')
    out_to_file.write(str(relative_energy_list1[i]))
    out_to_file.write('\n')  
out_to_file.close()

#in_from_file=open('PHE.scan1.neg.reversed.10deg-start.log.ffTK','r')
in_from_file=open(pos_scan_filename,'r')

plot_data_string_list2=in_from_file.readlines()

in_from_file.close()

angle_list2=[]
energy_list2=[]

for x in plot_data_string_list2:
    if 'dihedral' in x:
        y=x.split('=')
        angle_list2.append(float(y[1]))
    if 'EUMP2' in x:
        y=x.split('=')
        energy_string=''
        for i in y[2]:
            if i=='D':
                energy_string=energy_string+'E'
            else:
                energy_string=energy_string+i
        energy_list2.append(float(energy_string)*627.51)

print(angle_list2)
print(energy_list2)

relative_energy_list2=[]

for i in energy_list2:
    relative_energy_list2.append(i-min_energy1)

print(relative_energy_list2)

out_to_file=open('file2-plot-data.txt','w')
for i in range(len(angle_list2)):
    out_to_file.write(str(angle_list2[i]))
    out_to_file.write(',')
    out_to_file.write(str(relative_energy_list2[i]))
    out_to_file.write('\n')  
out_to_file.close()

plt.figure()
plt.plot(angle_list1,relative_energy_list1,"ob--")
plt.plot(angle_list2,relative_energy_list2,"+r--")
plt.savefig('crossing1.png')
