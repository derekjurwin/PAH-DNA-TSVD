import matplotlib.pyplot as plt

in_from_file=open('z_dih1_FEP_traj.agr','r')
string_from_file_list=in_from_file.readlines()
in_from_file.close()

step_list=[]
angle_list=[]
for i in range(3,len(string_from_file_list)-1,1):
    current_line_list=string_from_file_list[i].split()
    #print(current_line_list[1])
    step_list.append(float(current_line_list[0]))
    angle_list.append(float(current_line_list[1]))
      
plt.figure()
plt.plot(step_list,angle_list,",b")
plt.xlabel('Step')
plt.ylabel('Dihedral Angle (degrees)')
plt.title('Adduct Covalent Bond Dihedral Angle')
plt.savefig('0_18_dih1_FEP-traj.png')
#print(step_list)
#print(angle_list)

step_list_tossed=[]
angle_list_tossed=[]
index_counter=0
for i in angle_list:
    if i > 0:
        step_list_tossed.append(step_list[index_counter])
        angle_list_tossed.append(angle_list[index_counter])

    index_counter+=1

plt.figure()
plt.plot(step_list_tossed,angle_list_tossed,",b")
plt.xlabel('Step')
plt.ylabel('Dihedral Angle (degrees)')
plt.title('Adduct Covalent Bond Dihedral Angle - Data Filtered')
plt.savefig('0_18_dih1_FEP-traj_tossed.png')
