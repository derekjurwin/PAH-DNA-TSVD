import matplotlib.pyplot as plt
import statistics as stats
import os
import time

os.system('vmd -dispdev text -e measureRMSD.tcl -args dna_Na_WI dna_Na_WI aqua-equil2 aqua-equil2 "nucleic and not resid 1 9" 2 sim_RMSD2.dat')

in_from_file=open('sim_RMSD2.dat','r')
string_from_file_list=in_from_file.readlines()
in_from_file.close()

time_step_list=[]
RMSD_list=[]
for i in range(len(string_from_file_list)):
    current_line_list=string_from_file_list[i].split()
    #print(current_line_list[1])
    time_step_list.append(float(current_line_list[0]))
    RMSD_list.append(float(current_line_list[1]))

RMSD_avg=sum(RMSD_list)/len(RMSD_list) 
RMSD_stddev=stats.pstdev(RMSD_list)

plt.figure()
plt.plot(time_step_list,RMSD_list,",g")
plt.xlabel('Time (ns)')
plt.ylabel('RMSD')
plt.title('DNA Duplex RMSD')
plt.annotate('Avg RMSD = '+str(RMSD_avg)+'\n Std dev = '+str(RMSD_stddev),xy=(0,max(RMSD_list)-0.5))
plt.savefig('0_19_traj_RMSD2.png')

