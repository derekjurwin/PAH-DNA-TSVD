import matplotlib.pyplot as plt
import statistics as stats
import os
import time

in_from_file=open('y_dih_E.agr','r')
string_from_file_list=in_from_file.readlines()
in_from_file.close()

time_step_list=[]
y_list=[]
for i in range(3,len(string_from_file_list)-1,1):
    current_line_list=string_from_file_list[i].split()
    #print(current_line_list[1])
    time_step_list.append(float(current_line_list[0]))
    y_list.append(float(current_line_list[1]))

y_avg=round(sum(y_list)/len(y_list),4)
y_stddev=round(stats.pstdev(y_list),4)

plt.figure()
plt.plot(time_step_list,y_list,",y")
plt.xlabel('Time Step')
plt.ylabel('Energy (kcal/mol)')
plt.title('Total Energy')
plt.annotate('Avg RMSD = '+str(y_avg)+'\n Std dev = '+str(y_stddev),xy=(0,min(y_list)-0.5))
plt.savefig('0_22_dih_energy.png')

