import matplotlib.pyplot as plt
import statistics as stats
import os
import time

in_from_file=open('y_testing123','r')
string_from_file_list=in_from_file.readlines()
in_from_file.close()

time_step_list=[]
bond_list=[]
angle_list=[]
dihed_list=[]
impr_list=[]
elec_list=[]
vdw_list=[]
conf_list=[]
nonbond_list=[]
total_list=[]
for i in range(1,len(string_from_file_list),1):
    current_line_list=string_from_file_list[i].split()
    #print(current_line_list[1])
    time_step_list.append(float(current_line_list[0]))
    bond_list.append(float(current_line_list[2]))
    angle_list.append(float(current_line_list[3]))
    dihed_list.append(float(current_line_list[4]))
    impr_list.append(float(current_line_list[5]))
    elec_list.append(float(current_line_list[6]))
    vdw_list.append(float(current_line_list[7]))
    conf_list.append(float(current_line_list[8]))
    nonbond_list.append(float(current_line_list[9]))
    total_list.append(float(current_line_list[10]))

plt.figure()
plt.plot(time_step_list,total_list,"--b")
plt.xlabel('Time Step')
plt.ylabel('Energy (kcal/mol)')
plt.title('Total Energy')
plt.savefig('0_23_total_energy_stack.png')

plt.figure()
plt.plot(time_step_list,nonbond_list,"--r")
plt.xlabel('Time Step')
plt.ylabel('Energy (kcal/mol)')
plt.title('Nonbonded Energy')
plt.savefig('0_23_nonbond_energy_stack.png')

plt.figure()
plt.plot(time_step_list,vdw_list,"--g")
plt.xlabel('Time Step')
plt.ylabel('Energy (kcal/mol)')
plt.title('VdW Energy')
plt.savefig('0_23_vdw_energy_stack.png')

plt.figure()
plt.plot(time_step_list,elec_list,"--m")
plt.xlabel('Time Step')
plt.ylabel('Energy (kcal/mol)')
plt.title('Electrostatic Energy')
plt.savefig('0_23_elec_energy_stack.png')
