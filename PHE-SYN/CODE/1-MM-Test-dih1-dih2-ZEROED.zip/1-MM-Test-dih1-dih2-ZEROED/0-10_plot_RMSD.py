import matplotlib.pyplot as plt
import os
import time

os.system('sh measureRMSD.sh')

in_from_file=open('sim_RMSD.dat','r')
string_from_file_list=in_from_file.readlines()
in_from_file.close()

time_step_list=[]
RMSD_list=[]
for i in range(len(string_from_file_list)):
    current_line_list=string_from_file_list[i].split()
    #print(current_line_list[1])
    time_step_list.append(float(current_line_list[0]))
    RMSD_list.append(float(current_line_list[1]))
      
plt.figure()
plt.plot(time_step_list,RMSD_list,",g")
plt.xlabel('Time (ns)')
plt.ylabel('RMSD')
plt.title('DNA Duplex RMSD')
plt.savefig('0_19_traj_RMSD.png')

