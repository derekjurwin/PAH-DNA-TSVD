import matplotlib.pyplot as plt
import statistics as stats
import os
import time

os.system('vmd -dispdev text -e measureRMSD.tcl -args dna_Na_WI dna_Na_WI aqua-equil2 aqua-equil2 "index 96 to 234 424 to 522" 2 PAH-stacking_RMSD.dat')

in_from_file=open('PAH-stacking_RMSD.dat','r')
string_from_file_list=in_from_file.readlines()
in_from_file.close()

time_step_list=[]
RMSD_list=[]
for i in range(len(string_from_file_list)):
    current_line_list=string_from_file_list[i].split()
    #print(current_line_list[1])
    time_step_list.append(float(current_line_list[0]))
    RMSD_list.append(float(current_line_list[1]))

RMSD_avg=round(sum(RMSD_list)/len(RMSD_list),4)
RMSD_stddev=round(stats.pstdev(RMSD_list),4)

plt.figure()
plt.plot(time_step_list,RMSD_list,",k")
plt.xlabel('Time (ns)')
plt.ylabel('RMSD')
plt.title('PAH Stacking RMSD')
plt.annotate('Avg RMSD = '+str(RMSD_avg)+'\n Std dev = '+str(RMSD_stddev),xy=(0,max(RMSD_list)-0.5))
plt.savefig('0_21_PAH-stacking_RMSD.png')

